import subprocess
import os

os.chdir("/home/shares/stephan/RPi");

subprocess.call(["./Server"])